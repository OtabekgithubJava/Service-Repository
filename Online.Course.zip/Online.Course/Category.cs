namespace Online.Course
{
    public class Category
    {
        public int Id { get; set; }
        public string Category_name { get; set; }
    }
}
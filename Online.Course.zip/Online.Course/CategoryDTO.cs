namespace Online.Course
{
    public class CategoryDTO
    {
        public string Category_name { get; set; }
    }
}
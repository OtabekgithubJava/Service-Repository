namespace Online.Course
{
    public class CustomersDTO
    {
        public string Full_Name { get; set; }
        public int Age { get; set; }
    }
}
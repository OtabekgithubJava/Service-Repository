namespace Online.Course
{
    public class Customers
    {
        public int Id { get; set; }
        public string full_Name { get; set; }
        public int Age { get; set; }
    }
}
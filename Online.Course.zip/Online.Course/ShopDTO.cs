namespace Online.Course
{
    public class ShopsDTO
    {
        public string Shop_Name { get; set; }
    }
}
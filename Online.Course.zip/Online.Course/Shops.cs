namespace Online.Course
{
    public class Shops
    {
        public int Id { get; set; }
        public string Shop_Name { get; set; }
    }
}